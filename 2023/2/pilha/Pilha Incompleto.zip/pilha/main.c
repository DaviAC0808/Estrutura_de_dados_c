#include <stdio.h>
#include <stdlib.h>


void menu(){


 int op;  //op��o recursiva

 do{
         system("cls");
         printf("\n Pilha: \n");


          printf("\n\n");
          printf("1 - Empilhar \n");
          printf("2 - Desempilhar \n");
          printf("3 - Sair \n ");

          printf("\n\n Informe a opcao :>_");
          scanf("%d",&op);

        switch(op){

         case 1:{


            break;
         }

         case 2:{

              break;

         }

        case 3:
          op=3;
        }

  }while(op != 3);
}



int main()
{

    menu();
    printf("\n");
    return 0;
}



//
//
//pilha* createpilha(pilha *p){
//    p->topo=NULL;
//    return p;
//}
//
//
//int pilha_vazia(pilha *p){
// if(p->topo == NULL){
//       return 1;
// }else{
//  return 0;
// }
//}
//
//
//

//
//int desempilha(pilha *p){
//
//  int elemento;
//
//  Tpilha *aux=(Tpilha*)malloc(sizeof(Tpilha));
//  aux= p->topo; //cria auxiliar e aponta para o topo
//
//  p->topo= aux->ant; //baixa o topo
//  elemento = aux->item;
//  aux->ant = NULL;
//  free(aux);
//  return elemento;
//
//}
//
//
//void mostra_pilha(pilha *p){
//
//  if(pilha_vazia(p)==1){
//     printf("pilha vazia!!!");
//  }else{
//
//      Tpilha *aux=(Tpilha*)malloc(sizeof(Tpilha));
//      aux= p->topo; //cria auxiliar e aponta para o topo
//
//      while(aux!=NULL){
//        printf("%d \n",aux->item);
//        aux=aux->ant;
//      }
//  }
//
//}
